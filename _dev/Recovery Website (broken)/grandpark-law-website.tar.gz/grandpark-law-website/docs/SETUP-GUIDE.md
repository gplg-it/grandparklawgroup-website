# Grand Park Law Group - Insights Page Setup Guide

## Overview

Your new Insights page integrates with **two content management systems**:

| System | Best For | Who Uses It |
|--------|----------|-------------|
| **Ghost CMS** | Long-form articles, newsletters, legal analysis | Marketing team, attorneys |
| **Google Sheets** | Quick updates, announcements, case results | All staff |

Both sources feed into the same beautiful Insights page automatically.

---

## Quick Start Checklist

- [ ] Set up Ghost CMS account
- [ ] Create Google Sheet from template
- [ ] Configure the Insights page with your credentials
- [ ] Test both integrations
- [ ] Train your team

---

## Part 1: Ghost CMS Setup

### Step 1: Create a Ghost Account

1. Go to [ghost.org](https://ghost.org) and click **Start your free trial**
2. Choose a subdomain (e.g., `grandparklaw.ghost.io`)
3. Complete the setup wizard

**Pricing:**
- Starter: $9/month (up to 500 members)
- Creator: $25/month (up to 1,000 members)
- Self-hosted: Free (requires technical setup)

### Step 2: Configure Ghost Settings

1. Log into your Ghost Admin panel (`yoursite.ghost.io/ghost`)
2. Go to **Settings** â†’ **Integrations**
3. Click **+ Add custom integration**
4. Name it "Website Integration"
5. Copy the **Content API Key** (you'll need this later)

### Step 3: Set Up Tags for Categories

Create these tags in Ghost (**Tags** section):

| Tag Name | Slug | Description |
|----------|------|-------------|
| Newsletter | `newsletter` | Quarterly newsletters |
| Legal | `legal` | Legal updates & analysis |
| Case | `case` | Case results & victories |
| Community | `community` | Community involvement |
| News | `news` | Firm announcements |

### Step 4: Create Your First Post

1. Click **+ New post** in Ghost
2. Write your article using the rich editor
3. Add a **tag** (this determines the category)
4. Toggle **Feature this post** if it should appear in the carousel
5. Add a **feature image** (recommended: 1200x630px)
6. Click **Publish**

### Ghost Writing Tips

- **Excerpts**: Add a custom excerpt in Post Settings for better preview text
- **Reading Time**: Ghost calculates this automatically
- **SEO**: Use the built-in SEO settings for meta descriptions
- **Scheduling**: Schedule posts in advance for consistent publishing

---

## Part 2: Google Sheets Setup

### Step 1: Create Your Sheet

1. Go to [Google Sheets](https://sheets.google.com)
2. Create a new spreadsheet
3. Name it "Grand Park Law Insights"
4. Import the template CSV file (File â†’ Import)

### Step 2: Sheet Column Reference

| Column | Description | Required | Example |
|--------|-------------|----------|---------|
| `title` | Article headline | âœ… Yes | "Partner Named to Top 100 Trial Lawyers" |
| `category` | Content type | âœ… Yes | "Firm News" (see options below) |
| `date` | Publication date | âœ… Yes | 2024-12-15 |
| `excerpt` | Brief summary | âœ… Yes | 2-3 sentences describing the article |
| `image` | Feature image URL | No | https://example.com/image.jpg |
| `featured` | Show in carousel? | No | TRUE or FALSE |
| `readtime` | Estimated minutes | No | 5 |
| `url` | Link to full article | No | External URL if hosted elsewhere |
| `status` | Publication status | âœ… Yes | Published or Draft |
| `author` | Author name | No | "John Smith" |

### Category Options

Use these exact category names for proper filtering:

- `Quarterly Newsletter`
- `Legal Updates`
- `Case Results`
- `Firm News`
- `Community`

### Step 3: Publish Your Sheet

1. Go to **File** â†’ **Share** â†’ **Publish to web**
2. Select the sheet tab (not "Entire Document")
3. Choose **Comma-separated values (.csv)** format
4. Click **Publish**
5. Copy the generated URL

**Important:** The URL should look like:
```
https://docs.google.com/spreadsheets/d/e/XXXXX/pub?output=csv
```

### Step 4: Set Permissions

1. Click **Share** button
2. Under "General access", select:
   - "Anyone with the link" â†’ "Viewer"

This allows the website to read the data without requiring login.

---

## Part 3: Configure the Insights Page

### Update the CONFIG Object

Open `grandpark-insights-v2.html` and find the `CONFIG` object near the top of the `<script>` section:

```javascript
const CONFIG = {
    // Ghost CMS Configuration
    ghost: {
        url: 'https://grandparklaw.ghost.io', // Your Ghost URL
        apiKey: 'abc123def456...', // Your Content API Key
        enabled: true // Set to true to enable
    },
    // Google Sheets Configuration  
    sheets: {
        csvUrl: 'https://docs.google.com/spreadsheets/d/e/XXXXX/pub?output=csv',
        enabled: true // Set to true to enable
    },
    // Display Settings
    itemsPerPage: 9,
    featuredCount: 4
};
```

### Testing Your Configuration

1. Save the file
2. Open in a browser
3. Check the browser console (F12) for any errors
4. Verify articles from both sources appear

---

## Part 4: Content Workflow

### Recommended Workflow

```
â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚                    CONTENT TYPE GUIDE                       â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚                                                             â”‚
â”‚  GHOST CMS (Full Articles)                                  â”‚
â”‚  â”œâ”€â”€ Quarterly Newsletters                                  â”‚
â”‚  â”œâ”€â”€ Legal Analysis & Updates                               â”‚
â”‚  â”œâ”€â”€ Long-form Case Studies                                 â”‚
â”‚  â””â”€â”€ Thought Leadership Pieces                              â”‚
â”‚                                                             â”‚
â”‚  GOOGLE SHEETS (Quick Updates)                              â”‚
â”‚  â”œâ”€â”€ Settlement/Verdict Announcements                       â”‚
â”‚  â”œâ”€â”€ Staff Promotions & New Hires                          â”‚
â”‚  â”œâ”€â”€ Award Recognitions                                     â”‚
â”‚  â”œâ”€â”€ Event Announcements                                    â”‚
â”‚  â””â”€â”€ Community Involvement Updates                          â”‚
â”‚                                                             â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
```

### Publishing Cadence (Suggested)

| Content Type | Frequency | Platform |
|--------------|-----------|----------|
| Quarterly Newsletter | Every 3 months | Ghost |
| Legal Updates | 2-4 per month | Ghost |
| Case Results | As they occur | Sheets |
| Firm News | As needed | Sheets |
| Community | Monthly | Sheets |

---

## Part 5: Training Your Team

### For Non-Technical Staff (Google Sheets)

**Adding a New Article:**

1. Open the Google Sheet
2. Add a new row at the top (below headers)
3. Fill in all required columns
4. Set `status` to "Published"
5. Changes appear on the website within 5 minutes

**Editing an Existing Article:**

1. Find the row
2. Make your changes
3. Save (automatic)

**Removing an Article:**

Option A: Change `status` to "Draft"
Option B: Delete the row

### For Marketing Team (Ghost)

**Creating a Newsletter:**

1. Log into Ghost Admin
2. Click **+ New post**
3. Use the visual editor to write content
4. Add images, formatting, embeds
5. Add the "Newsletter" tag
6. Toggle "Feature this post" for carousel
7. Set publication date or publish immediately

**Editing Published Content:**

1. Find the post in Ghost
2. Click to edit
3. Make changes
4. Click **Update**

---

## Part 6: Troubleshooting

### Articles Not Appearing

**Ghost Posts:**
- Check the Content API key is correct
- Ensure posts are published (not drafts)
- Verify tags match expected categories
- Check browser console for API errors

**Google Sheets:**
- Verify the CSV URL is correct
- Ensure sheet is published to web
- Check `status` column says "Published"
- Confirm date format is YYYY-MM-DD

### Images Not Loading

- Use HTTPS URLs only
- Recommended size: 1200x630px
- Supported formats: JPG, PNG, WebP
- For Ghost: Upload directly to Ghost for best results

### Category Filtering Issues

Ensure categories match exactly:
- âœ… `Legal Updates`
- âŒ `legal updates` (lowercase)
- âŒ `Legal Update` (singular)

---

## Part 7: Advanced Customization

### Adding New Categories

1. Add new filter button in HTML:
```html
<button class="filter-tab" data-category="new-category">New Category</button>
```

2. Update the category mapping if using Ghost:
```javascript
const tagMap = {
    'newsletter': 'quarterly-newsletter',
    'legal': 'legal-updates',
    'new-tag': 'new-category' // Add this line
};
```

### Changing Display Settings

In the CONFIG object:
```javascript
itemsPerPage: 12,  // Show more articles per page
featuredCount: 6   // Show more featured articles
```

### Custom Styling

The page uses CSS custom properties. Modify these in the `:root` section:

```css
:root {
    --accent-gold: #c9a962;      /* Accent color */
    --primary-dark: #1a1915;     /* Background */
    --font-display: 'Cormorant Garamond', serif; /* Headlines */
}
```

---

## Support & Resources

### Ghost Documentation
- [Ghost Content API](https://ghost.org/docs/content-api/)
- [Ghost Themes](https://ghost.org/docs/themes/)
- [Ghost Tutorials](https://ghost.org/resources/)

### Google Sheets
- [Publish to Web](https://support.google.com/docs/answer/183965)
- [Data Validation](https://support.google.com/docs/answer/186103)

### Need Help?

Contact your web developer or IT support for:
- Custom integrations
- Design modifications
- Performance optimization
- Security updates

---

## Appendix: File Structure

```
grandpark-insights/
â”œâ”€â”€ grandpark-insights-v2.html    # Main insights page
â”œâ”€â”€ grandpark-insights-template.csv # Google Sheets template
â””â”€â”€ SETUP-GUIDE.md                # This documentation
```

---

*Last Updated: January 2025*
*Version: 2.0*
