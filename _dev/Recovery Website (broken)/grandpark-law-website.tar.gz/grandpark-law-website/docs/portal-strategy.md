# Grand Park Law Group â€” Portal Strategy Analysis

## Executive Summary

This document analyzes Squire Patton Boggs' client/staff portal implementation and proposes a comprehensive dual-portal system for Grand Park Law Group that integrates with existing infrastructure while providing superior client experience and operational efficiency.

---

## Part I: Squire Patton Boggs Portal Analysis

### Architecture Overview

Squire Patton Boggs employs a **gateway model** â€” a branded landing page that routes users to appropriate external systems based on their role. The `/login/` page features:

| Section | Target System | Purpose |
|---------|---------------|---------|
| Client Login | MyMatter Extranet (regionalized: APAC, EMEA, US) | Client matter access |
| Attorney/Staff Login | Outlook Web Access | Email access |
| Remote Desktop | Citrix Virtual Desktop (by region) | Full desktop access |
| Assistance | IT Support contact information | Help resources |

### Design Characteristics

- **Accordion-style interface**: Collapsible sections for each login category
- **Minimal authentication**: No embedded login forms â€” users click through to dedicated authentication systems
- **Regional segmentation**: Client extranets separated by geographic region
- **Self-service guidance**: PDF documentation for technical setup

### Strengths & Limitations

| Strengths | Limitations |
|-----------|-------------|
| Clean separation of concerns | No unified dashboard experience |
| Simple maintenance | Multiple authentication contexts |
| Regional load distribution | No integrated matter overview |
| Consistent branding at gateway | Relies on third-party extranet platforms |

---

## Part II: Grand Park Portal Requirements

### Client Portal Features

Based on the specified requirements, the client portal must provide:

1. **Matter Activity Dashboard**
   - Real-time timesheet data visualization
   - Billable hours summary by matter
   - Recent activity timeline
   - Attorney assignment visibility

2. **Deadline Management**
   - Google Calendar integration
   - Google Sheets synchronization
   - Visual timeline/calendar view
   - Email/SMS reminder triggers

3. **Invoice Management**
   - Outstanding invoice display
   - Payment processing (Invoice Ninja integration)
   - Payment history
   - Statement downloads

4. **Team Communication**
   - Secure messaging (Mattermost integration or custom)
   - Attorney contact information
   - Message history by matter

5. **Document Management**
   - Secure file upload
   - Document categorization by matter
   - Version tracking
   - Download access for client-facing documents

### Staff Portal Features

1. **Internal Application Access**
   - ERPNext/Frappe (practice management)
   - Invoice Ninja (billing)
   - Listmonk (newsletters)
   - Mautic (marketing automation)
   - Directus CMS (content management)

2. **Communication Tools**
   - Mattermost (team messaging)
   - Webmail access

3. **Document Repository**
   - Internal templates
   - Procedure manuals
   - Training materials

---

## Part III: Proposed Architecture

### Option A: Unified Portal (Recommended)

A single-page application with role-based authentication that dynamically renders appropriate interfaces.

```
â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚                    portal.grandparklawgroup.com                 â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚                                                                 â”‚
â”‚  â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”    â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â” â”‚
â”‚  â”‚  Authentication     â”‚â”€â”€â”€â–¶â”‚  Role Detection                â”‚ â”‚
â”‚  â”‚  (SSO/OAuth)        â”‚    â”‚  (Client vs Staff)             â”‚ â”‚
â”‚  â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜    â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¬â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜ â”‚
â”‚                                           â”‚                     â”‚
â”‚              â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¼â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”â”‚
â”‚              â”‚                            â”‚                    â”‚â”‚
â”‚              â–¼                            â–¼                    â”‚â”‚
â”‚  â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”    â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”   â”‚â”‚
â”‚  â”‚   CLIENT DASHBOARD    â”‚    â”‚    STAFF DASHBOARD        â”‚   â”‚â”‚
â”‚  â”‚                       â”‚    â”‚                           â”‚   â”‚â”‚
â”‚  â”‚  â€¢ Matter Activity    â”‚    â”‚  â€¢ Application Launcher   â”‚   â”‚â”‚
â”‚  â”‚  â€¢ Deadlines          â”‚    â”‚  â€¢ Quick Links            â”‚   â”‚â”‚
â”‚  â”‚  â€¢ Invoices           â”‚    â”‚  â€¢ Internal Resources     â”‚   â”‚â”‚
â”‚  â”‚  â€¢ Messages           â”‚    â”‚  â€¢ Team Directory         â”‚   â”‚â”‚
â”‚  â”‚  â€¢ Documents          â”‚    â”‚  â€¢ Announcements          â”‚   â”‚â”‚
â”‚  â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜    â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜   â”‚â”‚
â”‚                                                                â”‚â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
```

### Option B: Gateway Model (Squire Patton Boggs Style)

Branded landing page that routes to separate portals.

```
â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚                grandparklawgroup.com/portal                     â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚                                                                 â”‚
â”‚   â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”   â”‚
â”‚   â”‚                    CLIENT ACCESS                        â”‚   â”‚
â”‚   â”‚                                                         â”‚   â”‚
â”‚   â”‚    [Matter Portal]    [Pay Invoice]    [Upload Docs]   â”‚   â”‚
â”‚   â”‚                                                         â”‚   â”‚
â”‚   â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜   â”‚
â”‚                                                                 â”‚
â”‚   â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”   â”‚
â”‚   â”‚                    STAFF ACCESS                         â”‚   â”‚
â”‚   â”‚                                                         â”‚   â”‚
â”‚   â”‚    [Internal Apps]    [Mattermost]    [Resources]      â”‚   â”‚
â”‚   â”‚                                                         â”‚   â”‚
â”‚   â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜   â”‚
â”‚                                                                 â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
```

---

## Part IV: Technology Stack Integration

### Existing Infrastructure Mapping

| Requirement | Existing System | Integration Method |
|-------------|-----------------|-------------------|
| Timesheet/Matter Data | Frappe/ERPNext | REST API |
| Invoice Display/Payment | Invoice Ninja | REST API + Payment Gateway |
| Calendar Deadlines | Google Calendar | Google Calendar API |
| Deadline Sync | Google Sheets | Sheets API |
| Team Communication | Mattermost | Mattermost API / Embed |
| Document Storage | Directus / Synology | Directus API |
| User Management | Keycloak / Auth System | OAuth 2.0 / OIDC |

### Data Flow Architecture

```
â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚                        CLIENT PORTAL                            â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¬â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
                            â”‚
                            â–¼
â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚                      API GATEWAY                                 â”‚
â”‚                   (Node.js / Express)                           â”‚
â”‚                                                                 â”‚
â”‚  Endpoints:                                                     â”‚
â”‚  â€¢ /api/matters       â†’ ERPNext                                 â”‚
â”‚  â€¢ /api/invoices      â†’ Invoice Ninja                           â”‚
â”‚  â€¢ /api/deadlines     â†’ Google Calendar + Sheets                â”‚
â”‚  â€¢ /api/messages      â†’ Mattermost                              â”‚
â”‚  â€¢ /api/documents     â†’ Directus                                â”‚
â”‚                                                                 â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¬â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
                            â”‚
            â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¼â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¬â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
            â–¼               â–¼               â–¼               â–¼
       â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”    â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”    â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”    â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”
       â”‚ ERPNext â”‚    â”‚ Invoice â”‚    â”‚ Google  â”‚    â”‚Directus â”‚
       â”‚         â”‚    â”‚  Ninja  â”‚    â”‚  APIs   â”‚    â”‚   CMS   â”‚
       â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜    â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜    â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜    â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
           VPS            VPS          External         NAS
```

---

## Part V: Implementation Phases

### Phase 1: Gateway Landing Page (Week 1-2)

Deliverables:
- [ ] Branded portal landing page (`/portal` route)
- [ ] Accordion-style interface matching Grand Park design system
- [ ] Client login section with matter portal link
- [ ] Staff login section with application launcher
- [ ] Mobile-responsive design

### Phase 2: Client Matter Dashboard (Week 3-5)

Deliverables:
- [ ] Authentication system (client credentials)
- [ ] ERPNext API integration for timesheet data
- [ ] Matter activity cards with recent entries
- [ ] Basic filtering by matter/date range

### Phase 3: Calendar & Deadline Integration (Week 6-7)

Deliverables:
- [ ] Google Calendar API connection
- [ ] Google Sheets webhook for deadline sync
- [ ] Visual timeline component
- [ ] Notification preferences

### Phase 4: Invoice & Payment Portal (Week 8-9)

Deliverables:
- [ ] Invoice Ninja API integration
- [ ] Invoice listing with status indicators
- [ ] Payment processing flow
- [ ] Receipt generation

### Phase 5: Communication & Documents (Week 10-12)

Deliverables:
- [ ] Mattermost channel integration (per-matter)
- [ ] Document upload interface
- [ ] Directus file storage integration
- [ ] Download portal for finalized documents

### Phase 6: Staff Portal Completion (Week 13-14)

Deliverables:
- [ ] Staff authentication (separate from client)
- [ ] Application launcher with SSO links
- [ ] Internal resource repository
- [ ] Team directory

---

## Part VI: Security Considerations

### Authentication Requirements

| Portal | Method | MFA | Session Duration |
|--------|--------|-----|------------------|
| Client | Email/Password + Optional OAuth | Recommended | 24 hours |
| Staff | SSO via GPLG identity provider | Required | 8 hours |

### Data Access Controls

- Client users can only view their associated matters
- Matter association managed in ERPNext
- Document uploads scanned for malware
- All API calls authenticated and logged
- HTTPS required (Cloudflare Origin Certificates)

### Compliance Notes

- Client communications are not privileged unless attorney-directed
- Invoice data subject to financial record retention
- Document uploads should have clear terms of use

---

## Part VII: Design Specifications

### Brand Alignment

The portal must adhere to the established Grand Park design system:

| Element | Specification |
|---------|---------------|
| Primary Background | `#1a1915` (warm charcoal) |
| Card Surfaces | `#2d2a24` (elevated charcoal) |
| Accent Color | `#c9a962` (champagne gold) |
| Display Typography | Cormorant Garamond, 300-400 weight |
| Body Typography | Outfit, 300-400 weight |
| Border Treatment | `rgba(201, 169, 98, 0.08)` at rest |

### Component Patterns

Refer to existing landing page for:
- Card hover effects
- Button styling (primary/secondary)
- Form input treatments
- Loading states
- Toast notifications

---

## Part VIII: Estimated Effort & Resources

### Development Hours

| Phase | Frontend | Backend | Integration | Total |
|-------|----------|---------|-------------|-------|
| Gateway Page | 16h | 4h | â€” | 20h |
| Client Dashboard | 24h | 32h | 16h | 72h |
| Calendar Integration | 8h | 16h | 12h | 36h |
| Invoice Portal | 16h | 24h | 16h | 56h |
| Communication | 16h | 24h | 20h | 60h |
| Staff Portal | 12h | 8h | 8h | 28h |
| **Total** | **92h** | **108h** | **72h** | **272h** |

### Infrastructure Requirements

- Cloudflare Pages (portal frontend)
- VPS Node.js API gateway service
- Additional Docker container for portal API
- Redis for session management (if not already deployed)

---

## Appendix A: Squire Patton Boggs Login Page Structure

```html
<!-- Key structural elements observed -->
<div class="c-expandable-copy-group">
    <div class="accordion-container">
        <div class="accordion-item expanded">
            <div class="accordion-header">
                <h3>Client Login</h3>
                <button class="accordion-toggle">...</button>
            </div>
            <div class="accordion-content">
                <p><a href="https://mymatter...">MyMatter Extranet - US</a></p>
            </div>
        </div>
        <!-- Additional accordion items for Staff, Remote Desktop, etc. -->
    </div>
</div>
```

---

## Appendix B: Recommended URL Structure

```
grandparklawgroup.com/
â”œâ”€â”€ portal/                    # Gateway landing page
â”œâ”€â”€ client/                    # Client portal application
â”‚   â”œâ”€â”€ dashboard/
â”‚   â”œâ”€â”€ matters/
â”‚   â”œâ”€â”€ invoices/
â”‚   â”œâ”€â”€ documents/
â”‚   â””â”€â”€ messages/
â””â”€â”€ staff/                     # Staff portal application
    â”œâ”€â”€ apps/
    â”œâ”€â”€ resources/
    â””â”€â”€ directory/

# Alternative subdomain approach:
portal.grandparklawgroup.com   # Gateway
client.grandparklawgroup.com   # Client portal
team.gplg.app                  # Staff internal (existing domain)
```

---

*Document prepared for Grand Park Law Group, A.P.C.*  
*Analysis Date: January 2025*
