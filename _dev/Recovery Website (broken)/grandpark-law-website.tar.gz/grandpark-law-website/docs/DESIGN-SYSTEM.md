# Grand Park Law Group - Design System & Color Schematic

## Brand Philosophy

The Grand Park Law visual identity evokes **sophistication, trust, and warmth** through a carefully curated palette of deep charcoals and champagne gold. The design draws inspiration from luxury hospitality and elite law firm aesthetics while maintaining approachability.

---

## Primary Color Palette

### Dark Foundation
```
┌─────────────────────────────────────────────────────────────────────────┐
│                                                                         │
│  PRIMARY DARK          PRIMARY CHARCOAL      PRIMARY WARM               │
│  #1a1915               #2d2a24               #3d3830                    │
│  ████████████          ████████████          ████████████               │
│  RGB: 26, 25, 21       RGB: 45, 42, 36       RGB: 61, 56, 48            │
│                                                                         │
│  Main background       Cards, elevated       Hover states,              │
│  Deep, warm black      surfaces              tertiary background        │
│                                                                         │
│  PRIMARY LIGHT                                                          │
│  #4a453c                                                                │
│  ████████████                                                           │
│  RGB: 74, 69, 60                                                        │
│                                                                         │
│  Borders, subtle                                                        │
│  divisions                                                              │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

### Champagne Gold Accent
```
┌─────────────────────────────────────────────────────────────────────────┐
│                                                                         │
│  ACCENT GOLD           ACCENT GOLD LIGHT     ACCENT GOLD DARK          │
│  #c9a962               #d4bc7d               #a68b4b                    │
│  ████████████          ████████████          ████████████               │
│  RGB: 201, 169, 98     RGB: 212, 188, 125    RGB: 166, 139, 75         │
│                                                                         │
│  Primary accent        Hover states          Pressed states,            │
│  CTAs, highlights      Light interactions    darker contexts            │
│                                                                         │
│  ACCENT GOLD GLOW                                                       │
│  rgba(201, 169, 98, 0.15)                                               │
│                                                                         │
│  Subtle glows,                                                          │
│  background radials                                                     │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

### Light Neutrals
```
┌─────────────────────────────────────────────────────────────────────────┐
│                                                                         │
│  CREAM                 CREAM DARK            OFF WHITE                  │
│  #f5f2eb               #e8e4db               #faf9f6                    │
│  ████████████          ████████████          ████████████               │
│  RGB: 245, 242, 235    RGB: 232, 228, 219    RGB: 250, 249, 246        │
│                                                                         │
│  Light section bg      Borders on light      Primary text color         │
│  Social connect bar    backgrounds           Headlines                  │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## Text Colors

```
┌─────────────────────────────────────────────────────────────────────────┐
│                                                                         │
│  TEXT LIGHT                    TEXT MUTED                               │
│  rgba(250, 249, 246, 0.9)      rgba(250, 249, 246, 0.55)               │
│                                                                         │
│  Body text, readable           Secondary text, dates,                   │
│  content on dark bg            meta information                         │
│                                                                         │
│  ─────────────────────────────────────────────────────────────────────  │
│                                                                         │
│  TEXT DARK                                                              │
│  #1a1915                                                                │
│                                                                         │
│  Text on light backgrounds                                              │
│  (cream sections)                                                       │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## Background Textures & Gradients

### Grid Pattern Overlay
```css
/* Subtle grid texture - 3% opacity */
background-image: 
    linear-gradient(90deg, var(--accent-gold) 1px, transparent 1px),
    linear-gradient(var(--accent-gold) 1px, transparent 1px);
background-size: 60px 60px;
opacity: 0.03;
```

### Radial Glow Effects
```css
/* Hero section gradient */
background: 
    radial-gradient(ellipse at 20% 30%, rgba(201, 169, 98, 0.06) 0%, transparent 50%),
    radial-gradient(ellipse at 80% 70%, rgba(201, 169, 98, 0.04) 0%, transparent 40%),
    linear-gradient(180deg, transparent 0%, var(--primary-dark) 100%);

/* Newsletter section */
background: 
    radial-gradient(ellipse at 30% 50%, rgba(201, 169, 98, 0.1) 0%, transparent 50%),
    radial-gradient(ellipse at 70% 50%, rgba(201, 169, 98, 0.06) 0%, transparent 40%);

/* Discovery section */
background: 
    radial-gradient(ellipse at 50% 100%, rgba(201, 169, 98, 0.08) 0%, transparent 60%);
```

### Border Treatments
```css
/* Subtle gold borders */
border: 1px solid rgba(201, 169, 98, 0.08);   /* Cards at rest */
border: 1px solid rgba(201, 169, 98, 0.15);   /* Inputs at rest */
border: 1px solid rgba(201, 169, 98, 0.2);    /* Hover state */
border: 1px solid rgba(201, 169, 98, 0.25);   /* Active/focus */

/* Decorative line */
background: linear-gradient(90deg, transparent, var(--accent-gold), transparent);
opacity: 0.3;
```

---

## Typography

### Font Families
```css
--font-display: 'Cormorant Garamond', Georgia, serif;
--font-body: 'Outfit', -apple-system, sans-serif;
```

### Usage
| Element | Font | Weight | Size | Letter Spacing |
|---------|------|--------|------|----------------|
| Hero Title | Cormorant Garamond | 300 | clamp(3.5rem, 10vw, 7rem) | — |
| Section Titles | Cormorant Garamond | 300-400 | clamp(2rem, 4vw, 3rem) | — |
| Card Titles | Cormorant Garamond | 400 | 1.25-1.5rem | — |
| Body Text | Outfit | 300 | 1rem | — |
| Labels/Tags | Outfit | 500 | 0.6-0.75rem | 0.2-0.4em |
| Navigation | Outfit | 400 | 0.7rem | 0.2em |

---

## Component-Specific Colors

### Cards
```
┌─────────────────────────────────────────┐
│  Background:  #2d2a24 (primary-charcoal)│
│  Border:      rgba(201, 169, 98, 0.06)  │
│  Border Hover: rgba(201, 169, 98, 0.2)  │
│  Shadow Hover: rgba(0, 0, 0, 0.3)       │
└─────────────────────────────────────────┘
```

### Buttons
```
┌─────────────────────────────────────────┐
│  PRIMARY (Filled)                       │
│  ─────────────────                      │
│  Background:  #c9a962                   │
│  Text:        #1a1915                   │
│  Hover BG:    #d4bc7d                   │
│                                         │
│  SECONDARY (Outline)                    │
│  ─────────────────                      │
│  Background:  transparent               │
│  Border:      #c9a962                   │
│  Text:        #faf9f6                   │
│  Hover BG:    #c9a962                   │
│  Hover Text:  #1a1915                   │
└─────────────────────────────────────────┘
```

### Form Inputs
```
┌─────────────────────────────────────────┐
│  Background:  #2d2a24                   │
│  Border:      rgba(201, 169, 98, 0.15)  │
│  Focus Border: #c9a962                  │
│  Focus Shadow: rgba(201, 169, 98, 0.1)  │
│  Text:        rgba(250, 249, 246, 0.9)  │
│  Placeholder: rgba(250, 249, 246, 0.55) │
└─────────────────────────────────────────┘
```

### Notifications
```
┌─────────────────────────────────────────┐
│  SUCCESS                                │
│  Background:  #065f46                   │
│  Border:      #059669                   │
│  Text:        #d1fae5                   │
│                                         │
│  ERROR                                  │
│  Background:  #7f1d1d                   │
│  Border:      #dc2626                   │
│  Text:        #fecaca                   │
│                                         │
│  INFO                                   │
│  Background:  #3d3830 (primary-warm)    │
│  Border:      #c9a962                   │
│  Text:        rgba(250, 249, 246, 0.9)  │
└─────────────────────────────────────────┘
```

### Source Badges
```
┌─────────────────────────────────────────┐
│  GHOST                                  │
│  Background:  rgba(21, 23, 26, 0.9)     │
│  Text:        #a0aec0                   │
│                                         │
│  DIRECTUS                               │
│  Background:  rgba(102, 68, 255, 0.9)   │
│  Text:        #ffffff                   │
│                                         │
│  SHEETS                                 │
│  Background:  rgba(52, 168, 83, 0.9)    │
│  Text:        #ffffff                   │
└─────────────────────────────────────────┘
```

---

## CSS Custom Properties (Copy-Ready)

```css
:root {
    /* Primary Colors */
    --primary-dark: #1a1915;
    --primary-charcoal: #2d2a24;
    --primary-warm: #3d3830;
    --primary-light: #4a453c;
    
    /* Accent - Champagne Gold */
    --accent-gold: #c9a962;
    --accent-gold-light: #d4bc7d;
    --accent-gold-dark: #a68b4b;
    --accent-gold-glow: rgba(201, 169, 98, 0.15);
    
    /* Neutrals */
    --cream: #f5f2eb;
    --cream-dark: #e8e4db;
    --off-white: #faf9f6;
    --text-light: rgba(250, 249, 246, 0.9);
    --text-muted: rgba(250, 249, 246, 0.55);
    --text-dark: #1a1915;
    
    /* Typography */
    --font-display: 'Cormorant Garamond', Georgia, serif;
    --font-body: 'Outfit', -apple-system, sans-serif;
}
```

---

## Color Relationships

```
                    LIGHT
                      ↑
                 #faf9f6 (off-white)
                 #f5f2eb (cream)
                 #e8e4db (cream-dark)
                      │
    ←─────────────────┼─────────────────→
    COOL              │              WARM
                      │
                 #d4bc7d (gold-light)
                 #c9a962 (gold) ← ACCENT
                 #a68b4b (gold-dark)
                      │
                 #4a453c (primary-light)
                 #3d3830 (primary-warm)
                 #2d2a24 (primary-charcoal)
                 #1a1915 (primary-dark)
                      ↓
                    DARK
```

---

## Accessibility Notes

| Combination | Contrast Ratio | WCAG |
|-------------|----------------|------|
| Gold (#c9a962) on Dark (#1a1915) | 7.2:1 | AAA ✓ |
| Off-white (#faf9f6) on Dark (#1a1915) | 15.8:1 | AAA ✓ |
| Text-light on Charcoal (#2d2a24) | 11.2:1 | AAA ✓ |
| Text-muted on Dark (#1a1915) | 7.1:1 | AAA ✓ |
| Dark (#1a1915) on Cream (#f5f2eb) | 14.5:1 | AAA ✓ |
| Gold (#c9a962) on Cream (#f5f2eb) | 2.1:1 | Decorative only |

---

## Usage Guidelines

### Do ✓
- Use gold sparingly for accents, CTAs, and highlights
- Maintain the warm undertone in all dark colors
- Use the grid texture at very low opacity (2-4%)
- Layer radial gradients for depth
- Use text-muted for secondary information

### Don't ✗
- Use pure black (#000000) — always use warm darks
- Use pure white (#ffffff) — use off-white instead
- Overuse gold — it should feel precious
- Apply gradients at high opacity
- Mix cool grays with the warm palette

---

## Sample Gradient Recipes

### Luxury Glow
```css
background: 
    radial-gradient(ellipse at 20% 30%, rgba(201, 169, 98, 0.08) 0%, transparent 50%),
    radial-gradient(ellipse at 80% 70%, rgba(201, 169, 98, 0.05) 0%, transparent 40%);
```

### Subtle Depth
```css
background: linear-gradient(180deg, 
    var(--primary-dark) 0%, 
    var(--primary-charcoal) 100%);
```

### Gold Line Accent
```css
background: linear-gradient(90deg, 
    transparent 0%, 
    var(--accent-gold) 50%, 
    transparent 100%);
height: 1px;
opacity: 0.3;
```

### Card Placeholder
```css
background: linear-gradient(135deg, 
    var(--primary-charcoal) 0%, 
    var(--primary-dark) 100%);
```

---

*Grand Park Law Group Design System v1.0*
*January 2025*
