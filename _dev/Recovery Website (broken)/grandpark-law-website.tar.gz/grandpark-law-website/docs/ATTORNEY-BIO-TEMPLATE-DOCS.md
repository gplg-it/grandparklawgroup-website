# Grand Park Law Group - Attorney Bio Page Template

## Documentation & Implementation Guide

**Version:** 1.0  
**Last Updated:** January 2025  
**Design Inspiration:** Skadden, Arps + Cravath, Swaine & Moore

---

## Table of Contents

1. [Overview](#overview)
2. [Design Philosophy](#design-philosophy)
3. [Quick Start](#quick-start)
4. [Template Structure](#template-structure)
5. [Placeholder Reference](#placeholder-reference)
6. [Photo Requirements](#photo-requirements)
7. [vCard Configuration](#vcard-configuration)
8. [Customization Guide](#customization-guide)
9. [Responsive Behavior](#responsive-behavior)
10. [Accessibility](#accessibility)
11. [SEO Optimization](#seo-optimization)
12. [Troubleshooting](#troubleshooting)

---

## Overview

This template provides a professional, modern attorney biography page for Grand Park Law Group. It combines best practices from top-tier law firm websites:

| Feature | Inspiration | Implementation |
|---------|-------------|----------------|
| Sidebar Navigation | Skadden | Sticky scrollspy sidebar |
| Utility Bar | Cravath | Share, PDF, Print, vCard actions |
| Tab Navigation | Cravath | Horizontal tabs on mobile |
| Photo Hero | Both | Split-screen hero layout |
| Content Cards | Cravath | Featured work display |
| Color Palette | Grand Park | Warm charcoal + champagne gold |

---

## Design Philosophy

### Visual Hierarchy
1. **Hero Section** - Immediate visual impact with professional photo and key info
2. **Utility Bar** - Quick actions for sharing/downloading
3. **Sidebar + Content** - Easy navigation through detailed information

### Typography Scale
- **Display (Cormorant Garamond):** Headlines, names, section titles
- **Body (Outfit):** All body text, navigation, UI elements

### Color Usage
- **Champagne Gold (`#c9a962`):** Accent color, links, highlights
- **Warm Charcoal (`#1a1915` - `#3d3830`):** Backgrounds, depth
- **Off-White (`#faf9f6`):** Primary text on dark backgrounds

---

## Quick Start

### Step 1: Copy the Template
```bash
cp grandpark-attorney-bio-template.html attorneys/[attorney-slug].html
```

### Step 2: Replace Placeholders
Find and replace all `{{PLACEHOLDER}}` values with actual content.

### Step 3: Add Photo
Place attorney photo at `/images/attorneys/[attorney-slug].jpg`

### Step 4: Update JavaScript Config
Edit the `ATTORNEY_DATA` object at the bottom of the file.

### Step 5: Test
- Check all links
- Test vCard download
- Verify responsive behavior
- Test print styling

---

## Template Structure

```
â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚  HEADER (Fixed)                                         â”‚
â”‚  Logo | Navigation Links | Menu Toggle                  â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚  BREADCRUMB                                             â”‚
â”‚  Home / Professionals / [Attorney Name]                 â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¬â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚                        â”‚                                â”‚
â”‚   PROFILE PHOTO        â”‚   PROFILE INFO                 â”‚
â”‚                        â”‚   Name, Title, Contact         â”‚
â”‚                        â”‚                                â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”´â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚  UTILITY BAR                                            â”‚
â”‚  Share | PDF | Print | vCard                            â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¬â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚                        â”‚                                â”‚
â”‚  SIDEBAR               â”‚   CONTENT SECTIONS             â”‚
â”‚  - Bio                 â”‚                                â”‚
â”‚  - Credentials         â”‚   [Bio Section]                â”‚
â”‚  - Featured Work       â”‚   [Credentials Section]        â”‚
â”‚  - Awards              â”‚   [Featured Work Section]      â”‚
â”‚  - Insights            â”‚   [Awards Section]             â”‚
â”‚                        â”‚   [Insights Section]           â”‚
â”‚  Related Practices     â”‚   [Contact CTA]                â”‚
â”‚                        â”‚                                â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”´â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚  FOOTER                                                 â”‚
â”‚  Brand | Practices | Firm | Connect | Legal             â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
```

---

## Placeholder Reference

### Required Placeholders

| Placeholder | Description | Example |
|-------------|-------------|---------|
| `{{ATTORNEY_FULL_NAME}}` | Full name as displayed | "Jennifer L. Martinez" |
| `{{ATTORNEY_SLUG}}` | URL-friendly name | "jennifer-martinez" |
| `{{ATTORNEY_TITLE}}` | Position title | "Partner" |
| `{{ATTORNEY_EMAIL}}` | Work email | "jmartinez@grandparklaw.com" |
| `{{ATTORNEY_PHONE}}` | Formatted phone | "(213) 555-1234" |
| `{{ATTORNEY_PHONE_RAW}}` | Phone for tel: link | "+12135551234" |
| `{{PRIMARY_PRACTICE_AREA}}` | Main practice | "Employment Law" |
| `{{PRIMARY_PRACTICE_SLUG}}` | Practice URL slug | "employment-law" |
| `{{ATTORNEY_SHORT_BIO}}` | 1-2 sentence summary | "Jennifer Martinez is a..." |
| `{{ATTORNEY_LEAD_STATEMENT}}` | Italicized lead | "A passionate advocate..." |

### Bio Content Placeholders

| Placeholder | Description |
|-------------|-------------|
| `{{BIO_PARAGRAPH_1}}` | First bio paragraph (always visible) |
| `{{BIO_PARAGRAPH_2}}` | Second bio paragraph (always visible) |
| `{{BIO_PARAGRAPH_3}}` | Third paragraph (in expandable section) |
| `{{BIO_PARAGRAPH_4}}` | Fourth paragraph (in expandable section) |
| `{{CASE_1_NAME}}` | Representative case name |
| `{{CASE_1_DESCRIPTION}}` | Case description |

### Education Placeholders

| Placeholder | Example |
|-------------|---------|
| `{{DEGREE_1}}` | "J.D." |
| `{{SCHOOL_1}}` | "UCLA School of Law" |
| `{{YEAR_1}}` | "2015" |
| `{{HONORS_1}}` | "Order of the Coif" |

### JavaScript Configuration

```javascript
const ATTORNEY_DATA = {
    firstName: 'Jennifer',
    lastName: 'Martinez',
    fullName: 'Jennifer L. Martinez',
    title: 'Partner',
    email: 'jmartinez@grandparklaw.com',
    phone: '+12135551234',
    phoneFormatted: '(213) 555-1234',
    organization: 'Grand Park Law Group, A.P.C.',
    address: {
        street: '123 Grand Park Ave, Suite 500',
        city: 'Los Angeles',
        state: 'CA',
        zip: '90012',
        country: 'USA'
    },
    url: 'https://www.grandparklaw.com/professionals/jennifer-martinez',
    photoUrl: 'https://www.grandparklaw.com/images/attorneys/jennifer-martinez.jpg'
};
```

---

## Photo Requirements

### Specifications

| Property | Requirement |
|----------|-------------|
| **Minimum Size** | 800 Ã— 1000 pixels |
| **Recommended Size** | 1200 Ã— 1500 pixels |
| **Aspect Ratio** | 4:5 (portrait) preferred |
| **Format** | JPG or WebP |
| **Max File Size** | 500KB (optimized) |
| **Background** | Professional, neutral |
| **Lighting** | Even, professional lighting |

### File Naming Convention
```
/images/attorneys/[attorney-slug].jpg
/images/attorneys/[attorney-slug]-og.jpg  (for social sharing, 1200x630px)
```

### Image Optimization
```bash
# Using ImageMagick
convert source.jpg -resize 1200x1500 -quality 85 attorneys/jennifer-martinez.jpg

# Create OG image
convert source.jpg -resize 1200x630^ -gravity center -extent 1200x630 attorneys/jennifer-martinez-og.jpg
```

---

## vCard Configuration

The template automatically generates vCard files for download. Configure the `ATTORNEY_DATA` object with accurate information.

### vCard Fields Generated
- Full Name (N, FN)
- Title (TITLE)
- Organization (ORG)
- Email (EMAIL)
- Phone (TEL)
- Address (ADR)
- URL
- Photo URL

### Testing vCard Download
1. Click the "vCard" button in utility bar
2. File should download as `LastName_FirstName.vcf`
3. Test importing into:
   - Apple Contacts
   - Google Contacts
   - Microsoft Outlook

---

## Customization Guide

### Adding/Removing Sections

**To add a new section:**
1. Add navigation item in sidebar:
```html
<a href="#new-section" class="sidebar-nav-item">New Section</a>
```

2. Add content section:
```html
<section id="new-section" class="content-section">
    <h2 class="section-title">New Section</h2>
    <!-- Content here -->
</section>
```

**To remove a section:**
1. Delete the sidebar nav item
2. Delete the corresponding content section

### Modifying Color Palette

Update CSS custom properties in `:root`:
```css
:root {
    --accent-gold: #c9a962;        /* Change accent color */
    --primary-dark: #1a1915;       /* Change background */
}
```

### Adding Practice Areas

In the sidebar section:
```html
<div class="sidebar-section">
    <h3 class="sidebar-section-title">Related Practices</h3>
    <a href="/practices/new-practice" class="practice-link">New Practice Area</a>
</div>
```

---

## Responsive Behavior

### Breakpoints

| Breakpoint | Behavior |
|------------|----------|
| **> 1024px** | Full sidebar + content layout |
| **768px - 1024px** | Horizontal tab navigation |
| **< 768px** | Stacked mobile layout |

### Mobile-Specific Changes
- Hero becomes stacked (photo on top, info below)
- Sidebar converts to horizontal scrollable tabs
- Utility bar buttons become equally spaced
- Footer converts to 2-column then 1-column grid

---

## Accessibility

### ARIA Labels
- All buttons have `aria-label` attributes
- Navigation has `aria-label="Page sections"`
- Breadcrumb has `aria-label="Breadcrumb"`

### Keyboard Navigation
- All interactive elements are focusable
- Tab order follows visual hierarchy
- Enter/Space triggers buttons

### Color Contrast
- Text meets WCAG AA standards against backgrounds
- Gold accent passes contrast requirements

### Screen Reader Optimization
- Semantic HTML structure
- Proper heading hierarchy (h1 â†’ h2 â†’ h3)
- Descriptive link text

---

## SEO Optimization

### Meta Tags Included
- Title tag with attorney name and firm
- Meta description with short bio
- Canonical URL
- Open Graph tags for social sharing
- Twitter Card tags

### Structured Data (JSON-LD)
The template includes Attorney schema markup:
```json
{
    "@context": "http://schema.org",
    "@type": "Attorney",
    "name": "...",
    "jobTitle": "...",
    "worksFor": { ... },
    "alumniOf": [ ... ],
    "knowsAbout": [ ... ]
}
```

### URL Structure
Recommended: `/professionals/[first-name]-[last-name]`
Example: `/professionals/jennifer-martinez`

---

## Troubleshooting

### vCard Not Downloading
- Check browser allows blob downloads
- Verify `ATTORNEY_DATA` has valid values
- Try different browser

### Sidebar Not Sticky
- Check parent container doesn't have `overflow: hidden`
- Verify sticky positioning browser support

### Images Not Loading
- Verify file path is correct
- Check file permissions
- Confirm image format is supported

### Print Styling Issues
- Use Chrome's print preview
- Check `@media print` styles
- Verify elements with `display: none !important`

### Mobile Menu Not Working
- Check JavaScript console for errors
- Verify menu toggle event listener is attached
- Check mobile breakpoint CSS

---

## File Checklist

When creating a new attorney bio page, ensure you have:

- [ ] HTML file with all placeholders replaced
- [ ] Attorney headshot photo (800Ã—1000px minimum)
- [ ] OG image for social sharing (1200Ã—630px)
- [ ] Updated `ATTORNEY_DATA` JavaScript object
- [ ] Verified all internal links work
- [ ] Tested vCard download
- [ ] Checked mobile responsiveness
- [ ] Validated structured data (Google's Rich Results Test)
- [ ] Proofread all content

---

## Support

For questions or customizations, contact:
- Web Development: [developer@grandparklaw.com]
- Content Updates: [marketing@grandparklaw.com]

---

*This documentation accompanies the Grand Park Law Group Attorney Bio Template v1.0*
