# Image Assets — Grand Park Law Group

The following image files are referenced in the HTML but were never deployed
to the production server. They must be created and placed here before full
visual fidelity is achieved.

## Required Files

| File | Path | Dimensions | Notes |
|------|------|-----------|-------|
| `favicon.svg` | `/assets/images/favicon.svg` | 32×32 | SVG favicon, gold monogram recommended |
| `apple-touch-icon.png` | `/assets/images/apple-touch-icon.png` | 180×180 | iOS home screen icon |
| `og-default.jpg` | `/assets/images/og-default.jpg` | 1200×630 | Default Open Graph share image |
| `logo.svg` | `/assets/images/logo.svg` | Variable | Full firm logo (referenced in JSON-LD) |
| `hero-poster.jpg` | `/assets/images/hero-poster.jpg` | 1920×1080 | Video fallback poster frame |

## Attorney Photos

| File | Path | Dimensions | Notes |
|------|------|-----------|-------|
| `jaafari.jpg` | `/assets/images/attorneys/jaafari.jpg` | 800×1000 | Armand Jaafari headshot |
| `rosario.jpg` | `/assets/images/attorneys/rosario.jpg` | 800×1000 | Danae Rosario headshot |

## Guidelines

- **Headshots**: Professional, neutral background, 4:5 aspect ratio
- **Format**: JPEG for photos (quality 85), SVG for icons/logos, PNG for transparency
- **Optimization**: Run through `squoosh.app` or similar before committing
- **Color**: Accent overlays should use `#c9a962` (champagne gold)

## External CDN Images (No Action Required)

These load from external CDNs and do not need local copies:

- Hero video: Mixkit CDN (`mixkit-plateaus-702-large.mp4`, `mixkit-palm-trees-1564-large.mp4`)
- Stock photography: Unsplash CDN
- Google Fonts: fonts.googleapis.com
